﻿enum eVertexArrayObject {
    VAOVerticesData,
    VAOCount
};
enum eBufferObject {
    VBOVerticesData,
    BOCount
};
enum eProgram {
    MainProgram,
    ProgramCount
};
enum eTexture {
    NoTexture,
    TextureCount
};

#include <common.cpp>

GLchar windowTitle[] = "Bezier Curve (Pojekt 2)";
GLfloat aspectRatio;

GLint dragged = -1;     // A dragelt pont indexe, -1 ha nincs

bool dragStarted = false;   // True ha az egérgomb lenyomásakor dragelünk valamit, False ha üres helyre kattintottunk (új pont)

glm::dvec2 mousePressPos;   //  Az egérmutató normalizált koordinátái

static vector<vec2> controlPoints;      // kontrollpontok listája
static vector<vec2> pointToDraw;        // kiszámított és kirajzolandó pontok listája

GLint locationColor;        // A shader "uColor" uniform változójának helye


int NCR(int n, int r) {
    if (r == 0) return 1;

    if (r > n / 2) return NCR(n, n - r);

    long res = 1;
    for (int k = 1; k <= r; k++) {
        res *= n - k + 1;
        res /= k;
    }
    return res;
}

// It will be the Bernstein basis polynomial of degree n
GLfloat blending(GLint n, GLint i, GLfloat t) {
    return NCR(n, i) * pow(t, i) * pow(1.0f - t, n - i);
}

// Feltölti a pointToDraw vektort a Bézier-görbe pontjaival
void drawBezierCurve(const vector<vec2>& controlPoints) {
    pointToDraw.clear();

    glm::vec3 nextPoint;
    GLfloat   t = 0.0f, B;
    GLfloat   increment = 1.0f / 100.0f;

    while (t <= 1.0f) {
        nextPoint = glm::vec3(0.0f, 0.0f, 0.0f);

        for (int i = 0; i < controlPoints.size(); i++) {
            B = blending(controlPoints.size() - 1, i, t);
            nextPoint.x += B * controlPoints.at(i).x;
            nextPoint.y += B * controlPoints.at(i).y;
        }
        pointToDraw.push_back(nextPoint);
        t += increment;
    }
}

// pixelkoordinátát normalizált világ koordinátákká alakítja
glm::dvec2 pixelToNDC(double xPixel, double yPixel) {
    glm::dvec2 pos;

    pos.x = xPixel * 2.0 / windowWidth - 1.0;
    pos.y = (windowHeight - yPixel) * 2.0 / windowHeight - 1.0;

    if (windowWidth < windowHeight)
        pos.y /= aspectRatio;
    else
        pos.x *= aspectRatio;

    return pos;
}

/* Megkeresi azt a kontrollpontot amelyik az egérpozícióhoz legközelebb van sensitivity sugarú körön belül
   Visszatérési érték: a pont indexe, -1 ha nincs ilyen pont */
GLint getActivePoint(const vector<vec2>& pts, float sensitivity, vec2 mousePos) {
    float sensSq = sensitivity * sensitivity;

    for (GLint i = 0; i < pts.size(); i++) {
        vec2  delta = pts[i] - mousePos;
        float distSq = dot(delta, delta);
        if (distSq < sensSq)
            return i;
    }
    return -1;
}

void initShaderProgram() {
    ShaderInfo shaderInfo[ProgramCount][3] = { {
        { GL_VERTEX_SHADER,   "./vertexShader.glsl"   },
        { GL_FRAGMENT_SHADER, "./fragmentShader.glsl" },
        { GL_NONE, nullptr }
    } };

    for (int programItem = 0; programItem < ProgramCount; programItem++) {
        program[programItem] = LoadShaders(shaderInfo[programItem]);

        locationColor = glGetUniformLocation(program[programItem], "uColor");
    }

    glBindVertexArray(VAO[VAOVerticesData]);
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOVerticesData]);
    glBufferData(GL_ARRAY_BUFFER, 0, nullptr, GL_DYNAMIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(vec2), (GLvoid*)0);

    glUseProgram(program[MainProgram]);

}

// kör alakú kontrollpont rajzolása
void drawCircle(const vec2& center, float radius, int segments = 64) {
    vector<vec2> circleVerts;
    circleVerts.reserve(segments);

    for (int i = 0; i < segments; i++) {
        float angle = (2.0f * M_PI * i) / segments;
        circleVerts.push_back(center + vec2(cosf(angle) * radius, sinf(angle) * radius));
    }

    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOVerticesData]);
    glBufferData(GL_ARRAY_BUFFER, circleVerts.size() * sizeof(vec2), circleVerts.data(), GL_DYNAMIC_DRAW);
    glDrawArrays(GL_LINE_LOOP, 0, circleVerts.size());
}


void display(GLFWwindow* win, double currentTime) {
    glClear(GL_COLOR_BUFFER_BIT);

    // 2 * 4.0f = 8 px (3 <= d <= 9)
    float radiusNDC = (4.0f / glm::min(windowWidth, windowHeight)) * 2.0f * worldSize;

    if (controlPoints.size() == 1) {    // Csak 1 kontrollpont
        glUniform4f(locationColor, 1.0f, 0.0f, 0.0f, 1.0f); // Piros
        drawCircle(controlPoints[0], radiusNDC);
        return;
    }


    //Bézier görbe 
    glUniform4f(locationColor, 0.0f, 0.0f, 1.0f, 1.0f); // Kék
    glLineWidth(4.0f);

    glBindVertexArray(VAO[VAOVerticesData]);

    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOVerticesData]);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(pointToDraw.size() * sizeof(vec2)), pointToDraw.data(), GL_DYNAMIC_DRAW);
    glDrawArrays(GL_LINE_STRIP, 0, (GLsizei)pointToDraw.size());


    // Kontroll poligon
    glUniform4f(locationColor, 0.0f, 1.0f, 0.0f, 1.0f); // Sárga
    glLineWidth(1.0f);

    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOVerticesData]);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(controlPoints.size() * sizeof(vec2)), controlPoints.data(), GL_DYNAMIC_DRAW);
    glDrawArrays(GL_LINE_STRIP, 0, (GLsizei)controlPoints.size());


    // Kontrollpontok
    glUniform4f(locationColor, 1.0f, 0.0f, 0.0f, 1.0f); // Piros
    glLineWidth(7.5f);

    // Minden kontrollponthoz egy kör
    for (const auto& cp : controlPoints) {
        drawCircle(cp, radiusNDC);
    }
}


void framebufferSizeCallback(GLFWwindow* win, int width, int height) {
    windowWidth = glm::max(width, 1);
    windowHeight = glm::max(height, 1);
    aspectRatio = (float)windowWidth / (float)windowHeight;

    glViewport(0, 0, windowWidth, windowHeight);
}

void keyCallback(GLFWwindow* win, int key, int scancode, int action, int mods) {
    // ESC
    if (action == GLFW_PRESS && key == GLFW_KEY_ESCAPE)
        glfwSetWindowShouldClose(win, GLFW_TRUE);

    if (action == GLFW_PRESS)
        keyboard[key] = GL_TRUE;
    else if (action == GLFW_RELEASE)
        keyboard[key] = GL_FALSE;
}

void cursorPosCallback(GLFWwindow* win, double xPos, double yPos) {
    if (dragged >= 0) {     // megfogtunk egy pontot
        glm::dvec2 worldPos = pixelToNDC(xPos, yPos);
        controlPoints[dragged] = vec2(worldPos.x, worldPos.y);

        drawBezierCurve(controlPoints);

        dragStarted = true;
    }
}

void mouseButtonCallback(GLFWwindow* win, int button, int action, int mods) {
    // BAL EGÉRGOMB LENYOMÁSA
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        double xPos, yPos;
        glfwGetCursorPos(win, &xPos, &yPos);
        mousePressPos = pixelToNDC(xPos, yPos);
        vec2 mp(mousePressPos.x, mousePressPos.y);

        float sens = 0.05f;

        dragged = getActivePoint(controlPoints, sens, mp);
        dragStarted = false;
    }

    // BAL EGÉRGOMB FELENGEDÉSE
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) {
        // Ha nem drag és nem fogtunk meg egyetlen pontot sem - új kontrollpontot
        if (!dragStarted && dragged == -1) {
            vec2 newPoint(mousePressPos.x, mousePressPos.y);

            controlPoints.push_back(newPoint);

            drawBezierCurve(controlPoints);

            cout << "Kontrollpont hozzáadva: (" << newPoint.x << ", " << newPoint.y << ")" << " | Fokszám: " << (controlPoints.size() - 1) << endl;
        }

        dragged = -1;
        dragStarted = false;
    }

    // JOBB EGÉRGOMB LENYOMÁSA
    if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS) {
        double xPos, yPos;
        glfwGetCursorPos(win, &xPos, &yPos);
        mousePressPos = pixelToNDC(xPos, yPos);
        vec2 mp(mousePressPos.x, mousePressPos.y);

        float sens = 0.05f;

        GLint found = getActivePoint(controlPoints, sens, mp);

        if (found >= 0) {
            cout << "Kontrollpont eltávolitva: i=" << found << " | Fokszam: " << (controlPoints.size() - 2) << endl;
            controlPoints.erase(controlPoints.begin() + found);

            drawBezierCurve(controlPoints);
        }
    }
}


int main(void) {
   
    init(3, 3, GLFW_OPENGL_COMPAT_PROFILE);

    glClearColor(0.2f, 0.2f, 0.2f, 0.0f);

    initShaderProgram();

    framebufferSizeCallback(window, windowWidth, windowHeight);

    setlocale(LC_ALL, "");
    cout << "Bal egérgomb (üres helyre)\t : uj kontrollpont hozzáadása" << endl;
    cout << "Bal egérgomb (pontra)\t\t : pont mozgatása (drag-and-drop)" << endl;
    cout << "Jobb egérgomb (pontra)\t\t : kontrollpont eltávolitása" << endl;
    cout << "ESC\t\t\t\t : kilépes" << endl;
    cout << endl;
    cout << "Szinek:" << endl;
    cout << "\tPiros\t= Kontrollpontok" << endl;
    cout << "\tZöld\t= Kontrollpoligon" << endl;
    cout << "\tKék\t= Bezier görbe" << endl;

    while (!glfwWindowShouldClose(window)) {
        display(window, glfwGetTime());
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    cleanUpScene(EXIT_SUCCESS);

    return EXIT_SUCCESS;
}