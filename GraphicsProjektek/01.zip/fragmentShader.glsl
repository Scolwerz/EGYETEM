// ============================================================
// fragmentShader.glsl  –  1–7. feladatpont
//
// Feladata:
//   Minden fragment (pixel) végső RGBA színét meghatározza.
//   Két rajzolási mód van (uDrawCircle alapján):
//     1) Kör mód (uDrawCircle == 1):
//        – A vT interpolációs paraméter alapján lineárisan keveri
//          a centrum és a szél színét (mix()).
//        – Ha uColorSwapped == 1, a centrum és a szél színe felcserélődik
//          (6. feladatpont: nincs metszés a szakasszal).
//     2) Szakasz mód (uDrawCircle == 0):
//        – Egyszínű rajzolás az uLineColor uniform alapján (kék).
//
// Bemeneti változók (vertex shaderből, GPU által interpolálva):
//   vT : float – interpolációs paraméter [0.0 .. 1.0]
//        0.0 = kör centruma
//        1.0 = kör határvonala
//        közte: lineárisan interpolált árnyalat
//
// Uniform változók (C++ oldalról glProgramUniform* hívásokkal):
//   uDrawCircle   : int  – 1 = kör, 0 = szakasz
//   uLineColor    : vec3 – szakasz rajzolási színe (kék)
//   uColorSwapped : int  – 1 = centrum/szél szín felcserélve (6. fp.),
//                          0 = eredeti sorrendben
// ============================================================

#version 330 core

// --- Bemenet (vertex shaderből, raszterizálás utáni interpolált érték) ---
in float vT;        // interpolációs paraméter [0.0 .. 1.0]

// --- Kimenet ---
out vec4 fragColor; // a fragment végső RGBA színe (ez kerül a framebufferbe)

// --- Uniform változók ---
uniform int  uDrawCircle;   // 1 = kör módban vagyunk, 0 = szakasz módban
uniform vec3 uLineColor;    // szakasz egyszínű rajzolási színe
uniform int  uColorSwapped; // 1 = centrum és szél színe felcserélve (6. fp.)

// ============================================================
// Kör belső színkonstansai (szabadon választott árnyalatok)
// Ezek a konstansok akkor érvényesek, ha uColorSwapped == 0.
// uColorSwapped == 1 esetén a két szín szerepet cserél.
// ============================================================

// Piros centrum (t=0): élénk piros, minimális zöld és kék komponenssel
const vec3 COLOR_CENTER = vec3(1.0, 0.08, 0.08);

// Zöld határvonal (t=1): élénk zöld, minimális piros és kék komponenssel
const vec3 COLOR_EDGE   = vec3(0.08, 0.92, 0.08);

void main() {

    if (uDrawCircle == 1) {
        // --------------------------------------------------------
        // KÖR ÁRNYALÁSA
        // --------------------------------------------------------

        // 6. feladatpont: ha a kör NEM metszi a szakaszt (uColorSwapped==1),
        // a két szín felcserélődik: a centrum zöld lesz, a szél piros.
        // Ha metszi (uColorSwapped==0), az eredeti sorrendet használjuk.
        vec3 cCenter, cEdge;
        if (uColorSwapped == 1) {
            // Felcserélt mód: centrum ← COLOR_EDGE (zöld), szél ← COLOR_CENTER (piros)
            cCenter = COLOR_EDGE;   // a középpont most zöld
            cEdge   = COLOR_CENTER; // a határvonal most piros
        } else {
            // Eredeti mód: centrum ← COLOR_CENTER (piros), szél ← COLOR_EDGE (zöld)
            cCenter = COLOR_CENTER; // a középpont piros
            cEdge   = COLOR_EDGE;   // a határvonal zöld
        }

        // Lineáris interpoláció a centrum és a szél színe között:
        //   mix(a, b, t) = a * (1.0 - t) + b * t
        //   t = 0.0  →  cCenter  (centrum árnyalata)
        //   t = 0.5  →  közbülső árnyalat (az interpolált belső pontok)
        //   t = 1.0  →  cEdge    (határvonal árnyalata)
        // A vT értéke a vertex shaderből érkezik, és a GPU automatikusan
        // interpolálta a kör centrum (t=0) és kerületi (t=1) csúcsai között.
        vec3 col = mix(cCenter, cEdge, vT);

        // alpha = 1.0: a kör teljesen átlátszatlan
        fragColor = vec4(col, 1.0);

    } else {
        // --------------------------------------------------------
        // SZAKASZ ÁRNYALÁSA
        // --------------------------------------------------------
        // Egyszínű rajzolás: az uLineColor uniform határozza meg a színt.
        // A C++ oldalon ez kékre van beállítva: vec3(0.0, 0.2, 1.0).
        // vT értéke itt közömbös, nem vesszük figyelembe.
        fragColor = vec4(uLineColor, 1.0);
    }
}
