// ============================================================
// main.cpp  –  1–7. feladatpont
//
//  1. 600×600-as négyzetes ablak, sárga háttér
//  2. r=50px sugarú kör: piros centrum, zöld határvonal,
//     lineárisan interpolált belső árnyalatokkal
//  3. Kör vízszintes visszapattanása (pontosan érinti a falat)
//  4. Kék, 3px vastag, 200px széles vízszintes szakasz az ablak közepén
//  5. FEL/LE nyíl: a szakasz mozgatása y irányban
//  6. Ha a körlap NEM metszi a szakaszt, a centrum és a szél színe felcserélődik
//  7. α=25° irányvektorral S billentyűre indul a kör, falakon visszapattan
//
// Felépítés: közös common.cpp + template_main.cpp mintájára épülő
// enum/callback szerkezet.
// ============================================================

// ============================================================
// ENUM-OK  –  a common.cpp #include ELŐTT kötelező definiálni,
// mert a common.cpp ezekből határozza meg a VAO/BO/program tömbök méretét.
// ============================================================

/** Vertex Array Object (VAO) azonosítók. */
enum eVertexArrayObject {
    VAOCircle,  // kör háromszögeinek geometriájához
    VAOLine,    // vízszintes szakasz geometriájához
    VAOCount    // tömbméret-sentinel (common.cpp glGenVertexArrays(VAOCount,...))
};

/** Buffer Object (VBO) azonosítók. */
enum eBufferObject {
    VBOCircle,  // kör csúcsadatait tároló VBO
    VBOLine,    // szakasz csúcsadatait tároló VBO
    BOCount     // tömbméret-sentinel
};

/** Shader program azonosítók. */
enum eProgram {
    MainProgram,    // egyetlen vertex+fragment shader program
    ProgramCount    // tömbméret-sentinel
};

/** Textúra azonosítók (nem használunk textúrát, de a common.cpp elvárja). */
enum eTexture {
    NoTexture,      // 0 méretű tömb elkerülésére
    TextureCount
};

// ============================================================
// common.cpp behúzása
// Tartalmazza: GLEW, GLFW, GLM, SOIL2 fejléceket;
// globális VAO[], BO[], program[], texture[] tömböket;
// init(), cleanUpScene(), LoadShaders(), checkShaderLog() stb. segédfüggvényeket.
// ============================================================
#include "common.cpp"

// ============================================================
// Ablakcím  –  common.cpp extern GLchar windowTitle[]-ként várja
// ============================================================
GLchar windowTitle[] = "Bouncing Circle  [1-7. feladatpont]";

// ============================================================
// KÖR KONSTANSOK
// ============================================================
static const float CIRCLE_RADIUS   = 50.0f;  // kör sugara pixelben
static const int   CIRCLE_SEGMENTS = 128;    // kerület hány háromszögre osztódik

// ============================================================
// SZAKASZ KONSTANSOK
// harmad oldalhossz = 600/3 = 200 px  →  fél = 100 px
// ============================================================
static const float LINE_HALF_PX    = 100.0f; // félhossz pixelben

// Szakasz lépésköze egy FEL/LE nyomásra pixelben
// (5. feladatpont: mozgatható szakasz)
static const float LINE_STEP_PX    = 10.0f;

// ============================================================
// MOZGÁSÁLLAPOT – KÖR
// ============================================================
static float circleX = 0.0f;  // kör középpontjának aktuális X-je NDC-ben
static float circleY = 0.0f;  // kör középpontjának aktuális Y-ja NDC-ben

// Sebességvektor (NDC/frame).
// Értéke (0,0) amíg S-t nem nyomnak; S lenyomáskor α=25° szerint töltjük fel.
static float velX    = 0.0f;
static float velY    = 0.0f;

// Jelzi, hogy a kör már mozgásban van-e (S lenyomása indítja el).
static bool  circleMoving = false;

// ============================================================
// MOZGÁSÁLLAPOT – SZAKASZ
// lineY: a szakasz középpontjának Y koordinátája NDC-ben
// (5. feladatpont: FEL/LE nyíllal mozgatható)
// ============================================================
static float lineY = 0.0f;    // kezdetben az ablak közepén (y=0)

// ============================================================
// SZÍNCSERE ÁLLAPOT
// (6. feladatpont: ha a kör NEM metszi a szakaszt, a centrum és
//  a szél színe felcserélődik a fragment shaderben)
// ============================================================
static bool colorSwapped = false; // false = eredeti színek, true = felcserélve

// ============================================================
// UNIFORM LOCATION-ÖK
// A shader program uniform változóinak elérési azonosítói,
// glGetUniformLocation()-nel kérdezzük le initShaderProgram()-ban.
// ============================================================
static GLint uCircleCenter  = -1; // vec2: kör középpontja NDC-ben
static GLint uDrawCircle    = -1; // int:  1 = kört rajzolunk, 0 = szakaszt
static GLint uLineColor     = -1; // vec3: szakasz egyszínű rajzolási színe
static GLint uColorSwapped  = -1; // int:  1 = centrum/szél szín felcserélve

// ============================================================
// pxToNDC()
// Pixel mértékegységből NDC (Normalized Device Coordinates) értékre vált.
// NDC tartomány: [-1, +1]  ↔  ablak: windowWidth pixel
// képlet: NDC = px * 2.0 / windowWidth
// ============================================================
static float pxToNDC(float px) {
    // 1 pixel = 2.0 / windowWidth NDC egység (az ablak teljes szélessége = 2 NDC)
    return px * 2.0f / (float)windowWidth;
}

// ============================================================
// initShaderProgram()
// Feladatai:
//   1. Betölti a GLSL fájlokat és összelinkel egy shader programot
//   2. Feltölti a kör és a szakasz VBO-ját csúcsadatokkal
//   3. Beállítja a VAO-k attribútum-leíróit
//   4. Lekérdezi az összes uniform location-t
//   5. Aktiválja a shader programot
// ============================================================
void initShaderProgram() {

    // ----------------------------------------------------------
    // Shader fájlok betöltése  (common.cpp LoadShaders)
    // ShaderInfo: { típus, fájlnév, shader_id }
    // ----------------------------------------------------------
    ShaderInfo shader_info[] = {
        { GL_VERTEX_SHADER,   "./vertexShader.glsl",   0 },
        { GL_FRAGMENT_SHADER, "./fragmentShader.glsl",  0 },
        { GL_NONE,            nullptr,                   0 }  // lista vége
    };
    /** LoadShaders: beolvassa, lefordítja és összelinkel egy teljes shader programot. */
    program[MainProgram] = LoadShaders(shader_info);

    // ==========================================================
    // KÖR VBO + VAO feltöltése
    //
    // Geometria: GL_TRIANGLE_FAN
    //   - 0. csúcs: centrum (t=0)
    //   - 1..CIRCLE_SEGMENTS+1. csúcs: kerületi pontok (t=1)
    //   - Az utolsó és az első kerületi pont egyenlő → a fan bezárul
    //
    // Csúcsformátum: [x, y, t]  (3 float/csúcs)
    //   x, y : pozíció az origóhoz képest NDC-ben
    //   t    : interpolációs paraméter [0=centrum, 1=szél]
    // ==========================================================

    // Sugár NDC egységekben: rNDC = CIRCLE_RADIUS * 2 / windowWidth
    float rNDC = pxToNDC(CIRCLE_RADIUS);

    // Összes csúcsszám: centrum(1) + kerület(CIRCLE_SEGMENTS) + záró ismétlés(1)
    int    vertCount   = CIRCLE_SEGMENTS + 2;
    float* circleVerts = new float[vertCount * 3]; // CPU oldali ideiglenes tömb

    // --- Centrum csúcs (index 0) ---
    circleVerts[0] = 0.0f; // x = 0 (origó)
    circleVerts[1] = 0.0f; // y = 0 (origó)
    circleVerts[2] = 0.0f; // t = 0 (centrum → piros)

    // --- Kerületi csúcsok (index 1 .. CIRCLE_SEGMENTS+1) ---
    for (int i = 0; i <= CIRCLE_SEGMENTS; ++i) {
        // Szög egyenletesen elosztva 0 .. 2π között
        float angle = 2.0f * (float)M_PI * i / CIRCLE_SEGMENTS;

        circleVerts[(i + 1) * 3 + 0] = rNDC * cosf(angle); // x = r·cos(α)
        circleVerts[(i + 1) * 3 + 1] = rNDC * sinf(angle); // y = r·sin(α)
        circleVerts[(i + 1) * 3 + 2] = 1.0f;               // t = 1 (szél → zöld)
    }

    /** BO[VBOCircle]-hoz kötjük a buffert, majd feltöltjük a csúcsadatokkal.
     *  GL_STATIC_DRAW: az adat GPU-ra kerül és ott marad (nem módosítjuk). */
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOCircle]);
    glBufferData(GL_ARRAY_BUFFER,
                 vertCount * 3 * sizeof(float), // bájtok száma
                 circleVerts,                   // pointer a CPU-s adatra
                 GL_STATIC_DRAW);

    /** VAO[VAOCircle] rögzíti, hogy a shader attribútumok honnan olvasnak. */
    glBindVertexArray(VAO[VAOCircle]);

    /** location=0: aPos – 2 float, stride=3 float, offset=0
     *  A GPU innen veszi az (x,y) koordinátákat a vertex shadernek. */
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE,
                          3 * sizeof(float), (GLvoid*)0);
    glEnableVertexAttribArray(0); // location=0 engedélyezése

    /** location=1: aT – 1 float, stride=3 float, offset=2*sizeof(float)
     *  A GPU innen veszi a t interpolációs paramétert. */
    glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE,
                          3 * sizeof(float), (GLvoid*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1); // location=1 engedélyezése

    glBindVertexArray(0);       // VAO kötés feloldása
    delete[] circleVerts;       // CPU-s ideiglenes tömb felszabadítása

    // ==========================================================
    // SZAKASZ VBO + VAO feltöltése
    //
    // Geometria: GL_LINES  (2 csúcspont)
    // Csúcsformátum: [x, y, t]  – t értéke közömbös a szakasznál
    // A szakasz a saját y-ján vízszintesen nyúlik el:
    //   bal:  (-halfNDC, 0, 0)
    //   jobb: (+halfNDC, 0, 0)
    // Az Y eltolást a vertex shader végzi el az uCircleCenter.y alapján.
    // ==========================================================
    float halfNDC = pxToNDC(LINE_HALF_PX); // félhossz NDC-ben
    float lineVerts[6] = {
        -halfNDC, 0.0f, 0.0f,  // bal végpont  (x=-halfNDC, y=0, t=0)
         halfNDC, 0.0f, 0.0f   // jobb végpont (x=+halfNDC, y=0, t=0)
    };

    /** BO[VBOLine]-hoz kötés és adatfeltöltés. */
    glBindBuffer(GL_ARRAY_BUFFER, BO[VBOLine]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(lineVerts), lineVerts, GL_STATIC_DRAW);

    /** VAO[VAOLine] attribútumainak konfigurálása. */
    glBindVertexArray(VAO[VAOLine]);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE,
                          3 * sizeof(float), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE,
                          3 * sizeof(float), (GLvoid*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    // ==========================================================
    // Uniform location-ök lekérdezése
    // Ha a visszaadott érték -1, a shader-ben nem létezik az adott uniform.
    // ==========================================================
    uCircleCenter = glGetUniformLocation(program[MainProgram], "uCircleCenter");
    uDrawCircle   = glGetUniformLocation(program[MainProgram], "uDrawCircle");
    uLineColor    = glGetUniformLocation(program[MainProgram], "uLineColor");
    uColorSwapped = glGetUniformLocation(program[MainProgram], "uColorSwapped");

    /** Shader program aktiválása: ezentúl ez fut a GPU-n. */
    glUseProgram(program[MainProgram]);
}

// ============================================================
// checkIntersection()
// Megvizsgálja, hogy a körlap és a vízszintes szakasz metszi-e egymást.
//
// A metszés feltétele:
//   A) Vízszintesen: a kör X középpontja és a szakasz [−halfNDC, +halfNDC]
//      intervalluma között legfeljebb rNDC távolság van.
//      Azaz: circleX − rNDC < halfNDC  ÉS  circleX + rNDC > −halfNDC
//      Egyenértékűen: |circleX| < halfNDC + rNDC
//
//   B) Függőlegesen: a kör Y középpontja és a szakasz Y értéke (lineY)
//      közötti távolság kisebb, mint a sugár.
//      Azaz: |circleY − lineY| < rNDC
//
// Visszatérési értéke true, ha metszés van (a két feltétel egyszerre teljesül).
// ============================================================
static bool checkIntersection() {
    float rNDC    = pxToNDC(CIRCLE_RADIUS); // sugár NDC-ben
    float halfNDC = pxToNDC(LINE_HALF_PX);  // szakasz félhossza NDC-ben

    // A) Vízszintes átfedés: a kör legbal szélétől a legjobb széléig
    //    legalább egy pont a szakasz vízszintes tartományában van-e?
    bool xOverlap = (circleX + rNDC > -halfNDC) &&
                    (circleX - rNDC <  halfNDC);

    // B) Függőleges távolság: a kör középpontja és a szakasz y-ja
    //    közelebb van-e egymáshoz, mint a sugár?
    bool yOverlap = fabsf(circleY - lineY) < rNDC;

    return xOverlap && yOverlap; // csak ha mindkét feltétel teljesül
}

// ============================================================
// updateCircle()
// Frissíti a kör pozícióját a (velX, velY) sebességvektor alapján.
//
// Visszapattanás a falakon – arányos tükrözéssel:
//   A kör középpontja x ∈ [-(1-rNDC), +(1-rNDC)] és
//                     y ∈ [-(1-rNDC), +(1-rNDC)] között mozoghat.
//   Ha egy lépés után a középpont kilépne ebből a tartományból,
//   a „túllépés" (overshoot) mértékét visszatükrözzük:
//       newPos = limit − overshoot
//   Így a kör pontosan érinti a falat, nem lóg ki.
//
//   Ha a kör nem mozog (circleMoving==false), a függvény nem csinál semmit.
// ============================================================
static void updateCircle() {
    // Ha még nem indult el (S nem volt lenyomva), nincs mit frissíteni
    if (!circleMoving) return;

    float rNDC  = pxToNDC(CIRCLE_RADIUS); // sugár NDC-ben
    float limit = 1.0f - rNDC;            // középpont maximális távolsága az origótól

    // --- X irány frissítése ---
    float newX = circleX + velX; // előzetesen számított új X pozíció

    if (newX > limit) {
        // Jobboldali falba ütközés: a túllépés mértékét visszatükrözzük
        float overshoot = newX - limit;  // mennyivel lóg túl a határon
        newX = limit - overshoot;        // tükrözés: a faltól ugyanannyit megy vissza
        velX = -velX;                    // X irányváltás
    } else if (newX < -limit) {
        // Baloldali falba ütközés
        float overshoot = -limit - newX;
        newX = -limit + overshoot;
        velX = -velX;
    }
    circleX = newX; // pozíció frissítése

    // --- Y irány frissítése ---
    float newY = circleY + velY; // előzetesen számított új Y pozíció

    if (newY > limit) {
        // Felső falba ütközés
        float overshoot = newY - limit;
        newY = limit - overshoot;
        velY = -velY;                    // Y irányváltás
    } else if (newY < -limit) {
        // Alsó falba ütközés
        float overshoot = -limit - newY;
        newY = -limit + overshoot;
        velY = -velY;
    }
    circleY = newY;
}

// ============================================================
// display()
// Minden frame-ben hívódik meg a főhurokból.
// Sorrendben:
//   1. Buffer törlése (sárga háttér)
//   2. Kör pozíció frissítése
//   3. Metszésvizsgálat → színcsere flag beállítása
//   4. Kör kirajzolása
//   5. Szakasz kirajzolása
// ============================================================
void display(GLFWwindow* /*window*/, double /*currentTime*/) {

    /** Töröljük a color buffert; a háttérszínt glClearColor adja meg (sárga). */
    glClear(GL_COLOR_BUFFER_BIT);

    /** 7. feladatpont: kör pozíció és sebesség frissítése visszapattanással. */
    updateCircle();

    /** 6. feladatpont: metszésvizsgálat – ha NEM metsz, cseréljük a színeket. */
    colorSwapped = !checkIntersection();

    // ----------------------------------------------------------
    // KÖR kirajzolása
    // ----------------------------------------------------------

    /** A kör középpontját NDC-ben elküldjük a vertex shadernek (uCircleCenter).
     *  A vertex shader ehhez adja hozzá az origóhoz képest értelmezett csúcs-
     *  koordinátákat, így a geometria a megfelelő helyre tolódik. */
    glProgramUniform2f(program[MainProgram], uCircleCenter, circleX, circleY);

    /** uDrawCircle=1: a fragment shader tudja, hogy kört kell árnyalni
     *  (piros↔zöld lineáris interpoláció). */
    glProgramUniform1i(program[MainProgram], uDrawCircle, 1);

    /** 6. feladatpont: színcsere jelző átküldése a fragment shadernek.
     *  Ha colorSwapped==true (nincs metszés), a shader felcseréli a centrum
     *  és a szél színét, ami az interpolált belső pontokra is hat. */
    glProgramUniform1i(program[MainProgram], uColorSwapped,
                       colorSwapped ? 1 : 0);

    /** VAO[VAOCircle] kötése: ez mondja meg a GPU-nak, honnan olvassa a csúcsokat. */
    glBindVertexArray(VAO[VAOCircle]);

    /** GL_TRIANGLE_FAN: az első csúcs (centrum) közös csúcsa minden háromszögnek;
     *  a többi csúcs sorban alkotja a kerületi háromszögeket. */
    glDrawArrays(GL_TRIANGLE_FAN, 0, CIRCLE_SEGMENTS + 2);

    glBindVertexArray(0); // VAO kötés feloldása rajzolás után

    // ----------------------------------------------------------
    // SZAKASZ kirajzolása
    // ----------------------------------------------------------

    /** A szakasz középpontjának eltolása: X=0 (középen), Y=lineY (mozgatható). */
    glProgramUniform2f(program[MainProgram], uCircleCenter, 0.0f, lineY);

    /** uDrawCircle=0: a fragment shader egyszínű rajzolást végez (uLineColor alapján). */
    glProgramUniform1i(program[MainProgram], uDrawCircle, 0);

    /** Kék szín beállítása: R=0.0, G=0.2, B=1.0 */
    glProgramUniform3f(program[MainProgram], uLineColor, 0.0f, 0.2f, 1.0f);

    /** 4. feladatpont: 3 pixel vastag vonal. */
    glLineWidth(3.0f);

    /** VAO[VAOLine] kötése: 2 végpont a szakaszhoz. */
    glBindVertexArray(VAO[VAOLine]);
    glDrawArrays(GL_LINES, 0, 2);
    glBindVertexArray(0);
}

// ============================================================
// framebufferSizeCallback()
// GLFW hívja, ha az ablak mérete megváltozik.
// Frissíti a viewport-ot, hogy a rajz mindig kitöltse az ablakot.
// ============================================================
void framebufferSizeCallback(GLFWwindow* /*window*/, int width, int height) {
    /** A minimalizálás (height→0) nem okoz osztás-nullával hibát. */
    windowWidth  = glm::max(width,  1);
    windowHeight = glm::max(height, 1);
    /** Viewport: a teljes ablakfelületen rajzolunk. */
    glViewport(0, 0, windowWidth, windowHeight);
}

// ============================================================
// keyCallback()
// Billentyűzetesemény-kezelő.
//
//  ESC        : ablak bezárása
//  FEL nyíl   : szakasz mozgatása felfelé  (5. feladatpont)
//  LE nyíl    : szakasz mozgatása lefelé   (5. feladatpont)
//  S          : kör elindítása α=25° irányvektorral (7. feladatpont)
// ============================================================
void keyCallback(GLFWwindow* window, int key, int /*scancode*/,
                 int action, int /*mods*/) {

    /** ESC: jelezzük a GLFW-nek, hogy be kell zárni az ablakot. */
    if (action == GLFW_PRESS && key == GLFW_KEY_ESCAPE)
        glfwSetWindowShouldClose(window, GLFW_TRUE);

    /** Billentyűállapot rögzítése a keyboard[] tömbben (common.cpp).
     *  Lehetővé teszi kombináció-vizsgálatot más helyeken is. */
    if (action == GLFW_PRESS)
        keyboard[key] = GL_TRUE;
    else if (action == GLFW_RELEASE)
        keyboard[key] = GL_FALSE;

    // ----------------------------------------------------------
    // 5. feladatpont: FEL/LE nyíl – szakasz mozgatása
    // ----------------------------------------------------------
    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        // LINE_STEP_PX pixel lépésközt NDC-re váltunk
        float stepNDC = pxToNDC(LINE_STEP_PX);

        if (key == GLFW_KEY_UP) {
            /** FEL nyíl: a szakasz Y koordinátájának növelése (felfelé mozgás). */
            lineY += stepNDC;
            // Korlátozzuk, hogy a szakasz ne lógjon ki az ablakon túl
            // (a szakasz y-ja legfeljebb 1.0 NDC lehet)
            if (lineY > 1.0f) lineY = 1.0f;
        }
        if (key == GLFW_KEY_DOWN) {
            /** LE nyíl: a szakasz Y koordinátájának csökkentése (lefelé mozgás). */
            lineY -= stepNDC;
            if (lineY < -1.0f) lineY = -1.0f;
        }
    }

    // ----------------------------------------------------------
    // 7. feladatpont: S billentyű – kör elindítása α=25° irányban
    // ----------------------------------------------------------
    if (action == GLFW_PRESS && key == GLFW_KEY_S) {
        /** α = 25 fok → radiánra: α_rad = 25 * π / 180 */
        float alpha = 25.0f * (float)M_PI / 180.0f;

        /** A 10 pixel hosszú irányvektor NDC-ben:
         *    velX = cos(α) * sebesség_NDC
         *    velY = sin(α) * sebesség_NDC
         *  A „10 pixel hosszú irányvektor" a mozgás irányát adja meg;
         *  a tényleges sebességet egy egységnyi sebesség-faktorra skálázzuk
         *  (SPEED_NDC), hogy az animáció folyékony legyen. */
        float SPEED_NDC = pxToNDC(3.0f); // ~3 pixel/frame sebesség NDC-ben

        velX = cosf(alpha) * SPEED_NDC; // vízszintes komponens: cos(25°) ≈ 0.906
        velY = sinf(alpha) * SPEED_NDC; // függőleges komponens: sin(25°) ≈ 0.423

        /** A kör visszaáll a képernyő közepére és elindul. */
        circleX = 0.0f;
        circleY = 0.0f;
        circleMoving = true; // ettől kezdve az updateCircle() mozgatja a kört
    }
}

// ============================================================
// Egér callback-ek – üres implementáció.
// A common.cpp extern-ként deklarálja őket, ezért kötelező megadni.
// ============================================================
void cursorPosCallback(GLFWwindow* /*window*/,
                       double /*xPos*/, double /*yPos*/) {}

void mouseButtonCallback(GLFWwindow* /*window*/,
                         int /*button*/, int /*action*/, int /*mods*/) {}

// ============================================================
// main()
// Az alkalmazás belépési pontja.
// ============================================================
int main(void) {

    /** init(major, minor, profil):
     *  – GLFW inicializálása és OpenGL 3.3 Core kontextus létrehozása
     *  – 600×600-as ablak megnyitása (windowWidth=600, windowHeight=600)
     *  – GLEW inicializálása (OpenGL függvénymutatók betöltése)
     *  – callback-ek regisztrálása (framebuffer, billentyű, egér)
     *  – VAO[] és BO[] tömbök generálása (glGenVertexArrays, glGenBuffers)
     *  – glClearColor beállítása (alapból arany; mi felülírjuk alább)
     *  – glfwSwapInterval(1): V-Sync bekapcsolva */
    init(3, 3, GLFW_OPENGL_CORE_PROFILE);

    /** 1. feladatpont: négyzetes ablak (az init() 600×600-at nyit, ezt rögzítjük). */
    glfwSetWindowAspectRatio(window, 1, 1);

    /** 1. feladatpont: sárga háttérszín. Az init() arany színt állít be;
     *  azt itt felülírjuk egy élénkebb sárgával. */
    glClearColor(1.0f, 0.88f, 0.0f, 1.0f); // R=1.0, G=0.88, B=0.0

    /** Shader program betöltése és VAO/VBO inicializálása. */
    initShaderProgram();

    /** Karakterkódolás beállítása a szövegek helyes megjelenítéséhez. */
    setlocale(LC_ALL, "");

    // ----------------------------------------------------------
    // Főhurok: addig fut, amíg a "close flag" be nem áll (ESC / ablakbezárás)
    // ----------------------------------------------------------
    while (!glfwWindowShouldClose(window)) {

        /** display(): törli a buffert, frissíti a pozíciót, rajzol. */
        display(window, glfwGetTime());

        /** Double buffering: a hátlapra rajzolt képet az előlapra cseréljük. */
        glfwSwapBuffers(window);

        /** glfwPollEvents(): feldolgozza a várakozó ablak- és eszközeseményeket
         *  (billentyű, egér, átméretezés stb.) és meghívja a callback-eket. */
        glfwPollEvents();
    }

    /** cleanUpScene(): törli a VAO-kat, VBO-kat, shader programokat,
     *  textúrákat; leállítja a GLFW-t; exit(EXIT_SUCCESS)-szel kilép. */
    cleanUpScene(EXIT_SUCCESS);

    return EXIT_SUCCESS; // cleanUpScene miatt ide nem jutunk el
}
