// ============================================================
// vertexShader.glsl  –  1–7. feladatpont
//
// Feladata:
//   Minden csúcsot a megfelelő NDC pozícióba transzformál.
//   Mind a kör, mind a szakasz csúcsai az origóhoz képest vannak
//   definiálva a VBO-ban; az uCircleCenter uniform eltolással
//   kerülnek a tényleges helyükre.
//
// Bemeneti attribútumok (VBO → VAO glVertexAttribPointer alapján):
//   location = 0  →  aPos : vec2 – csúcs (x,y) koordinátái
//                            az origóhoz képest, NDC egységekben
//   location = 1  →  aT   : float – interpolációs paraméter
//                            0.0 = kör centrum, 1.0 = kör határvonal
//                            (szakasznál közömbös)
//
// Uniform változók (C++ oldalról glProgramUniform* hívásokkal):
//   uCircleCenter : vec2 – az eltolás NDC-ben
//                   – kör esetén: a kör aktuális középpontja
//                   – szakasz esetén: (0, lineY) a szakasz Y pozíciója
//   uDrawCircle   : int  – 1 = kört rajzolunk, 0 = szakaszt
//                   (a vertex shaderben jelenleg nem használjuk,
//                    de konzisztencia miatt itt is deklaráljuk)
//
// Kimenet a fragment shader felé:
//   vT : float – az aT attribútum változatlanul továbbítva;
//                a GPU a raszterizálás során lineárisan interpolálja
//                a háromszög csúcsai között
// ============================================================

#version 330 core

// --- Bemeneti attribútumok ---
layout(location = 0) in vec2  aPos; // csúcs pozíciója az origóhoz képest (NDC)
layout(location = 1) in float aT;   // interpolációs paraméter [0.0 .. 1.0]

// --- Uniform változók ---
uniform vec2 uCircleCenter; // eltolásvektor NDC-ben (kör középpontja vagy szakasz Y-ja)
uniform int  uDrawCircle;   // rajzolási mód (itt nem használjuk, de deklaráljuk)

// --- Kimenet a fragment shader felé ---
out float vT; // interpolációs paraméter, amelyet a GPU fragment-enként interpolál

void main() {
    // A csúcs végső NDC pozíciója = saját pozíció + eltolás.
    // Ez az egyetlen transzformáció: nincs MVP mátrix, mert NDC-ben dolgozunk.
    // Az origóhoz képest definiált geometria így kerül a kívánt helyre:
    //   – kör esetén: uCircleCenter = (circleX, circleY) → a kör középpontja
    //   – szakasz esetén: uCircleCenter = (0.0, lineY)   → a szakasz Y szintje
    gl_Position = vec4(aPos + uCircleCenter, 0.0, 1.0);
    //                  ^^^^   ^^^^^^^^^^^^
    //                  |      eltolás (uniform)
    //                  saját pozíció (attribútum)
    //                                              ^^^  z=0 (2D rajz, síkban)
    //                                                   ^^^  w=1 (homogén koord.)

    // Az interpolációs paramétert a fragment shadernek adjuk át.
    // A GPU az aT értéket a háromszög csúcsai között lineárisan interpolálja,
    // így a belső pixeleknél vT értéke 0.0 és 1.0 között lesz.
    vT = aT;
}
