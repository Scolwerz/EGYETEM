﻿enum eVertexArrayObject {
	VAOCubeData,
	VAOCount
};

enum eBufferObject {
	VBOCubeData,
	BOCount
};

enum eProgram {
	MainProgram,
	ProgramCount
};

enum eTexture {
	NincsTextura,
	TextureCount
};

#include "common.cpp"

GLchar windowTitle[] = "Cubes";
GLfloat aspectRatio;

const GLfloat CAMERA_R = 9.0f;		// Kamera henger sugár
const GLfloat ANGLE_SPEED = 0.02f;	// Kamera szög-sebesség
const GLfloat Z_SPEED = 0.1f;		// Kamera függőleges sebesség


GLfloat cameraAngle = 0.0f;			// Kamera mozgási szög
GLfloat cameraZ = 0.0f;				// Kamera kezdeti magasság
vec3 cameraPos = vec3(CAMERA_R, 0.0f, 0.0f);	// Kamera pozíció
vec3 cameraORIGO = vec3(0.0f, 0.0f, 0.0f);		// Kamera origoba néz
vec3 cameraUpVector = vec3(0.0f, 0.0f, 1.0f);

// Sor: x, y, z ,nx, ny, nz (normálvektor)
GLfloat cubeData[] = {
	// Hátsó (z = -0.5), (0, 0, -1)
	-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
	 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
	 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
	 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
	-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,
	-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,

	// Első (z = 0.5), (0, 0, 1)
	-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
	 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
	 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
	 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
	-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,
	-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,

	// Bal (x = -0.5), (-1, 0, 0)
	-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,
	-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
	-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
	-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,
	-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,
	-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,

	// Jobb (x = 0.5), (1, 0, 0)
	 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,
	 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
	 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
	 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,
	 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,
	 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,

	 // Alsó (y = -0.5), (0, -1, 0)
	 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,
	  0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,
	  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
	  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
	 -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,
	 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,

	 // Felső (y = 0.5), (0, 1, 0) 
	 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,
	  0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,
	  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
	  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
	 -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,
	 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f
};

vec3 cubePoints[3] = {
	vec3(0.0f,  0.0f,  0.0f),
	vec3(0.0f,  0.0f,  2.0f),
	vec3(0.0f,  0.0f, -2.0f)
};

GLuint cubeColorLoc;		// Kockák színének uniform locationje


void initShaderProgram() {
	ShaderInfo shaderInfo[] = {
		{ GL_VERTEX_SHADER,   "./vertexShader.glsl"   },
		{ GL_FRAGMENT_SHADER, "./fragmentShader.glsl"  },
		{ GL_NONE, nullptr }
	};

	program[MainProgram] = LoadShaders(shaderInfo);

	locationMatModel = glGetUniformLocation(program[MainProgram], "matModel");
	locationMatView = glGetUniformLocation(program[MainProgram], "matView");
	locationMatProjection = glGetUniformLocation(program[MainProgram], "matProjection");
	cubeColorLoc = glGetUniformLocation(program[MainProgram], "cubeColor");

	glBindVertexArray(VAO[VAOCubeData]);
	glBindBuffer(GL_ARRAY_BUFFER, BO[VBOCubeData]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeData), cubeData, GL_STATIC_DRAW);

	// location = 0: pozíció  
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// location = 1: normálvektor
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glUseProgram(program[MainProgram]);

	projectionType = Perspective;

	matModel = mat4(1.0f);
	matView = lookAt(cameraPos, cameraORIGO, cameraUpVector);

	glUniformMatrix4fv(locationMatModel, 1, GL_FALSE, value_ptr(matModel));
	glUniformMatrix4fv(locationMatView, 1, GL_FALSE, value_ptr(matView));
	glUniformMatrix4fv(locationMatProjection, 1, GL_FALSE, value_ptr(matProjection));

	glUniform3f(cubeColorLoc, 1.0f, 1.0f, 1.0f);	// Kockák színe

	glEnable(GL_DEPTH_TEST);	// Z-buffer
}


void updateCameraMat() {
	cameraPos.x = CAMERA_R * cos(cameraAngle);
	cameraPos.y = CAMERA_R * sin(cameraAngle);
	cameraPos.z = cameraZ;
	matView = lookAt(cameraPos, cameraORIGO, cameraUpVector);

	glUniformMatrix4fv(locationMatView, 1, GL_FALSE, value_ptr(matView));
}


void display(GLFWwindow* window, double currentTime) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(program[MainProgram]);

	if (keyboard[GLFW_KEY_LEFT])	// z tengely+ (óramutató ellentét)
		cameraAngle += ANGLE_SPEED;
	if (keyboard[GLFW_KEY_RIGHT])	// z tengely- (óramutató megyegyező)
		cameraAngle -= ANGLE_SPEED;
	if (keyboard[GLFW_KEY_UP])		// z tengelyen fel
		cameraZ += Z_SPEED;
	if (keyboard[GLFW_KEY_DOWN])	// z tengelyen le
		cameraZ -= Z_SPEED;

	updateCameraMat();

	// KOCKÁK
	for (int i = 0; i < 3; i++) {
		matModel = translate(mat4(1.0f), cubePoints[i]);

		glUniformMatrix4fv(locationMatModel, 1, GL_FALSE, value_ptr(matModel));
		glDrawArrays(GL_TRIANGLES, 0, sizeof(cubeData) / (6 * sizeof(GLfloat)));
	}
}

void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
	windowWidth = glm::max(width, 1);
	windowHeight = glm::max(height, 1);
	aspectRatio = (float)windowWidth / (float)windowHeight;
	float nearClipPlane = 0.1f;
	float farClipPlane = 200.0f;

	glViewport(0, 0, windowWidth, windowHeight);
	matProjection = perspective(
		radians(55.0f),		// Látószög 
		aspectRatio,
		nearClipPlane,
		farClipPlane
	);

	glUseProgram(program[MainProgram]);
	glUniformMatrix4fv(locationMatProjection, 1, GL_FALSE, value_ptr(matProjection));
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	// ESC
	if ((action == GLFW_PRESS) && (key == GLFW_KEY_ESCAPE))
		glfwSetWindowShouldClose(window, GLFW_TRUE);

	if (action == GLFW_PRESS)
		keyboard[key] = GL_TRUE;
	else if (action == GLFW_RELEASE)
		keyboard[key] = GL_FALSE;
}

void cursorPosCallback(GLFWwindow* window, double xPos, double yPos) {
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
}


int main(void) {

	init(3, 3, GLFW_OPENGL_COMPAT_PROFILE);

	glClearColor(0.2f, 0.2f, 0.2f, 0.0f);

	initShaderProgram();

	framebufferSizeCallback(window, windowWidth, windowHeight);

	setlocale(LC_ALL, "");
	cout << "ESC\t\tKilépéds" << endl;
	cout << "Bal nyíl:\tKamera forgatás z tengely körül balra" << endl;
	cout << "Jobb nyíl:\tKamera forgatás z tengely körül jobbra" << endl;
	cout << "Fel nyíl:\tKamera mozgatás z tengelyen fel" << endl;
	cout << "Le nyíl:\tKamera mozgatás z tengelyen le" << endl;	

	while (!glfwWindowShouldClose(window)) {
		display(window, glfwGetTime());
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	cleanUpScene(EXIT_SUCCESS);

	return EXIT_SUCCESS;
}
