#version 330

out vec4 fragColor;

uniform vec3 cubeColor;

void main(void) {
	fragColor = vec4(cubeColor, 1.0);
}
