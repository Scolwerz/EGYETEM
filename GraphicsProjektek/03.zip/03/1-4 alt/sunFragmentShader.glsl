#version 330

out vec4 fragColor;

uniform vec3 sunColor;

void main(void) {
	fragColor = vec4(sunColor, 1.0);
}
